> **TEMPLATE:** Copy this file, rename it, and fill in the placeholders. Delete this block in the copy.

## Slice or ticket and step

- Slice or ticket: <LINK>
- Step: <design | spec | database | tests | implement | review>

## What changed

<Two or three sentences.>

## Spec rules covered

| Rule ID | Decision (PRESERVE / CHANGE / RETIRE) | Covered by (test names) |
|---|---|---|
| R-00 | PRESERVE | `methodName_condition_expectedResult` |

## Test results

- Sandbox (H2): <command and outcome>
- CI Oracle suites (`oracle-integration`): <link and outcome>
- Coverage: <numbers vs thresholds>

## Oracle-specific constructs used

<MERGE, paging syntax, sequences, JSON functions, and so on. Write "none" if none.>

## H2 differences

<Link to the rows added in docs/db/h2-translation-notes.md. Write "none" if none.>

## Provisional names

<Objects named under provisional conventions. Write "none" if none.>

## Suspected legacy defects (replicated on purpose)

<Rule ID, what it does, evidence file:line. Write "none" if none.>

## New dependencies

<Name, version, licence, why. Write "none" if none.>

## Assumptions and open questions

<Keep this short. Prefer asking.>

## Definition of done (AGENTS.md section 11)

- [ ] Build passes
- [ ] Contract and rule-level parity tests pass
- [ ] Oracle suites pass in CI
- [ ] All legacy entry points accounted for
- [ ] Every rule has an approved decision
- [ ] No fixture, test or expected value changed to force a pass
- [ ] No legacy imports; no database access outside `infrastructure/persistence`
- [ ] Static analysis, formatting and coverage pass
- [ ] No secrets, PII or sensitive logging
