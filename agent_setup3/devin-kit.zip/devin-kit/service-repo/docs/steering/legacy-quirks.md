> **TEMPLATE:** Copy this file, rename it, and fill in the placeholders. Delete this block in the copy.

# Known legacy quirks

Recurring odd behavior found while reading legacy code. Each entry says what it does, not what it should do. The decision (keep, change or retire) lives in the spec.

| ID | What the legacy code does | Evidence (file:line) | Slices affected | Decision and approver |
|---|---|---|---|---|
| Q-01 | <DESCRIPTION> | <PATH/File.java:LINE> | <SLICES> | <PRESERVE / CHANGE / RETIRE, NAME, DATE> |
