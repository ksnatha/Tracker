> **TEMPLATE:** Copy this file, rename it, and fill in the placeholders. Delete this block in the copy.

# Glossary

One entry per domain term. Keep it short and current. When a term is resolved in a design or spec session, add it here immediately.

| Term | Meaning in the business | Legacy name(s) | Name in the new code | Notes and conflicts |
|---|---|---|---|---|
| <TERM> | <PLAIN-LANGUAGE MEANING> | <LEGACY TABLE, CLASS OR LABEL> | <NEW NAME> | <WHERE THE SAME WORD MEANS DIFFERENT THINGS> |
