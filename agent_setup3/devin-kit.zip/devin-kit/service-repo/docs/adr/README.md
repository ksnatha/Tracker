> **TEMPLATE:** Copy this file, rename it, and fill in the placeholders. Delete this block in the copy.

# Architecture decision records

One file per decision, named `NNNN-short-title.md`, written from `0000-template.md`.

## Statuses

- `proposed`: written by Devin or a human, not yet approved. Do not treat as settled.
- `approved`: a named human approved it. Follow it.
- `superseded`: replaced by a later ADR, which it links to.

Only a human changes `proposed` to `approved`.

## Index

| ADR | Title | Status | Date |
|---|---|---|---|
| 0001 | <TITLE> | proposed | <DATE> |
