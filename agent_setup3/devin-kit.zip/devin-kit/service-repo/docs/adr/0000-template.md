> **TEMPLATE:** Copy this file, rename it, and fill in the placeholders. Delete this block in the copy.

# NNNN. <Title>

- Status: proposed
- Date: <DATE>
- Deciders: <NAMES>
- Approved by: <NAME, DATE, or "pending">

## Context

<What forces the decision. Link the rules, evidence and gaps.>

## Options considered

1. <OPTION A>: <summary, pros, cons>
2. <OPTION B>: <summary, pros, cons>
3. <OPTION C>: <summary, pros, cons>

## Decision

<The option chosen and why.>

## Consequences

<What becomes easier, what becomes harder, what must be revisited.>

## Evidence

<file:line references, fixtures, metrics, links.>
