> **FILL-IN INSTRUCTIONS:** Copy this into a Devin Playbook. Placeholders like `<THIS>` are filled **per run** (slice, ticket, paths) unless marked ONE-TIME, which you fill once and keep. Search for `<` before every run. Delete this block in the copy you give Devin.

# Playbook 13: Retro and Handoff

Read `AGENTS.md` and `DEVIN.md` first. Do only this step. Run after each feature, or after every few tickets. Based on the AI Hero retro and handoff ideas.

## Inputs

- Feature: `<NAME>`
- Specs, plans, tickets, PRs and review comments for the feature

## Steps

1. Read the specs, tickets, PRs and review comments.
2. Write `<home repo>/docs/retros/<feature>.md` from the template: what worked, what surprised us, rules or decisions missing from the docs, tickets that were too large or badly ordered, review findings that repeated.
3. List the concrete updates needed to the glossary, ADRs, design docs, `AGENTS.md`, `DEVIN.md` and these playbooks. Apply only the updates I approve.
4. End with a short handoff: current state, what is next, open questions, files to read first.

## Done when

- The retro is committed and the approved doc updates are made
