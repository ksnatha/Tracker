> **TEMPLATE:** Copy this file, rename it, and fill in the placeholders. Delete this block in the copy.

# Design documents

| File | What it holds | Status |
|---|---|---|
| `architecture.md` | Target architecture (services, data ownership, communication, template engine, security) | <draft / approved> |
| `db-model.md` | Target DB model (Oracle is the source of truth) | <draft / approved> |
| `independent/modules.md` | Independent module design from the legacy code (Playbook 01 Part A) | <not started> |
| `independent/glossary-draft.md` | Draft domain terms found in the legacy code | <not started> |
| `boundary-comparison.md` | Target design versus independent design, per module | <not started> |
| `poc/` | Questionnaire POC architecture and decisions | <link or copy> |
| `nfr.md` | Non-functional baselines: performance, security, audit, availability | <not started> |

Only a human marks a document approved.
