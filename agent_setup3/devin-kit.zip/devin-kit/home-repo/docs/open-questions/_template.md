> **TEMPLATE:** Copy this file, rename it, and fill in the placeholders. Delete this block in the copy.

# Open questions: <SLICE OR SECTION>

Written so a business expert or DBA can answer without reading code. Answer in this file, with who answered and when.

| # | Question | What the legacy code does (file:line) | Why it matters / rules that depend on it | Options | Recommendation | Answer, by whom, date |
|---|---|---|---|---|---|---|
| 1 | <QUESTION> | <BEHAVIOR> | <IMPACT, RULE IDS> | <A / B> | <ONE LINE> | <pending> |
