> **TEMPLATE:** Copy this file, rename it, and fill in the placeholders. Delete this block in the copy.

# Retro: <FEATURE>

## What worked

<TEXT>

## What surprised us

<TEXT>

## Missing from the docs

<Rules, decisions, glossary terms, conventions that were not written down.>

## Tickets that were too big or badly ordered

<TEXT>

## Review findings that repeated

<TEXT>

## Updates to make (approve before applying)

- Glossary / steering: <ITEMS>
- ADRs / design: <ITEMS>
- Playbooks / AGENTS.md / DEVIN.md: <ITEMS>

## Handoff

- Current state: <TEXT>
- Next: <TEXT>
- Open questions: <LINKS>
- Read first: <FILES>
