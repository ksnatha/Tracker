> **TEMPLATE:** Copy this file, rename it, and fill in the placeholders. Delete this block in the copy.

# Design gaps

Gaps found while validating the design. Severity: blocker (stop work), major (fix before building the affected slice), minor.

| ID | Severity | Gap | Evidence (file:line, docs) | Confidence | Suggested fix | Status | Owner |
|---|---|---|---|---|---|---|---|
| G-01 | <blocker/major/minor> | <DESCRIPTION> | <EVIDENCE> | <GREEN/AMBER/RED> | <FIX> | <open/resolved> | <NAME> |
