> **TEMPLATE:** Copy this file, rename it, and fill in the placeholders. Delete this block in the copy.

# Ticket NNN: <SHORT TITLE>

- Status: todo
- Plan: <LINK>
- Blocked by: <TICKETS or "none">
- Repo: <SERVICE REPO>

## Goal

<One thin vertical slice that works end to end: API, service logic, persistence, tests.>

## Acceptance criteria

- <CRITERION>

## Rules covered

<Rule IDs and decisions.>

## Read first

<Docs, ADRs, specs, template JSON, SQL files.>

## Tests to write first

- Seams: <SEAMS>
- Parity cases: <FIXTURES OR EXAMPLES>

## Notes

<Anything the implementer must know. Keep it short.>
